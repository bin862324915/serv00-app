#!/bin/sh

export TMPDIR=/home/[username[]/nezha-agent/tmp

/home/[username[]/nezha-agent/agent -s [you host]:grcppoet -p [key] -d

EOF
